﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using LinqToDB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApp_Test.Models;

namespace WebApp_Test.Controllers
{
    [Route("/Company")]
    public class CompanyController : Controller
    {    

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost("AddCompany")]
        public IActionResult AddCompany(CompanyModel company)
        {
            var viewModel = new CompanyAddedViewModel
            {
                numbersOfCharsInName = company.CompanyName.Length,
                numbersOfCharsInDescription = company.Description.Length,
                isHidden = !company.isVisible
            };

            return View("CompanyAdded", viewModel);
        }

        [HttpPost("SaveToDb")]
        public IActionResult SaveToDb(CompanyAddedViewModel model)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CompaniesContext>();
            optionsBuilder.UseSqlServer("Data Source=JSYREK\\SQLEXPRESS2014;Initial Catalog=AdvTmp;Integrated Security=True");
            CompaniesContext _context = new CompaniesContext(optionsBuilder.Options);

            CompanyStoredInDbViewModel viewModel;
            if (ModelState.IsValid)
            {
                _context.companies.Add(model);
                _context.SaveChanges();

                viewModel = new CompanyStoredInDbViewModel
                {
                    Result = true
                };
            }
            else
            {
                viewModel = new CompanyStoredInDbViewModel
                {
                    Result = false
                };
            }
            return View("RecordStored", viewModel);
        }
        

       
    }
}