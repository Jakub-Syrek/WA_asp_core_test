﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp_Test.Models
{
    public class CompanyAddedViewModel
    {
        [Key]
        public int numbersOfCharsInName { get; set; }
        public int numbersOfCharsInDescription { get; set; }
        public bool isHidden { get; set; }
    }
}
