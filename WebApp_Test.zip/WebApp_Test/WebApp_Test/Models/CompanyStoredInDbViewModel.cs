﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp_Test.Models
{
    public class CompanyStoredInDbViewModel
    {
        [Key]
        public bool Result { get; set; }
    }
}
