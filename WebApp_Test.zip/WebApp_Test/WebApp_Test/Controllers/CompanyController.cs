﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using WebApp_Test.Models;

namespace WebApp_Test.Controllers
{
    [Route("/Company")]
    public class CompanyController : Controller
    {    

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost("GetLatestRecord")]
        public async System.Threading.Tasks.Task<IActionResult> GetLatestRecordAsync()
        {
            var optionsBuilder = new DbContextOptionsBuilder<CompaniesContext>();
            optionsBuilder.UseSqlServer("Data Source=JSYREK\\SQLEXPRESS2014;Initial Catalog=AdvTmp;Integrated Security=True");
            CompaniesContext _context = new CompaniesContext(optionsBuilder.Options);

            var companies = await _context.companies.ToListAsync();
            var lastIndex = companies.Count -1;
            var viewModel = new CompanyAddedViewModel
            {
                numbersOfCharsInName = companies[lastIndex].numbersOfCharsInName,
                numbersOfCharsInDescription = companies[lastIndex].numbersOfCharsInDescription,
                isHidden = companies[lastIndex].isHidden
            };
            return View("LastCompanyRetrieved", viewModel);
        }

        [HttpPost("AddCompany")]
        public IActionResult AddCompany(CompanyModel company)
        {
            if(company.CompanyName == null)
            {
                var viewModel_1 = new CompanyAddedViewModel
                {
                    numbersOfCharsInName = 0,
                    numbersOfCharsInDescription = 0,
                    isHidden = "false"
                };
                return View("CompanyAdded", viewModel_1);
            }


            var viewModel_2 = new CompanyAddedViewModel
            {
                numbersOfCharsInName = company.CompanyName.Length,
                numbersOfCharsInDescription = company.Description.Length,
                isHidden = Convert.ToString(!company.isVisible)
            };

            return View("CompanyAdded", viewModel_2);
        }

        [HttpPost("SaveToDb")]
        public IActionResult SaveToDb(CompanyAddedViewModel model)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CompaniesContext>();
            optionsBuilder.UseSqlServer("Data Source=JSYREK\\SQLEXPRESS2014;Initial Catalog=AdvTmp;Integrated Security=True");
            CompaniesContext _context = new CompaniesContext(optionsBuilder.Options);

            CompanyStoredInDbViewModel viewModel;
            if (ModelState.IsValid)
            {
                _context.companies.Add(model);
                _context.SaveChanges();

                viewModel = new CompanyStoredInDbViewModel
                {
                    Result = true
                };
            }
            else
            {
                viewModel = new CompanyStoredInDbViewModel
                {
                    Result = false
                };
            }
            return View("RecordStored", viewModel);
        }
        

       
    }
}